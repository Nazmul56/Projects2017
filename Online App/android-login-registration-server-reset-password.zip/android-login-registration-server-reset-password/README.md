# android-login-registration-server
PHP API for Android Login and Registration

Explanation : https://www.learn2crack.com/2016/04/android-login-registration-php-mysql-server.html
