<h1>Gradbar</h1>
<h3>Beautiful gradient Actionbar for your Android-app</h3>
![img](https://raw.githubusercontent.com/flouthoc/Gradbar/master/gradbar.gif)

<hr>
This is a simple implementation of ui gradients on android Actionbar. <strong> You liked it ? :smile: can you star :star: it ? </strong>


<h4>Usage</h4>
Usage is simple look at the source , still any trouble ? create an issue now.

<h4>Ack</h4>
Special thanks to https://twitter.com/_ighosh (http://uigradients.com)




<h1> Fork it</h1>
Twitter @flouthoc<br>
Email flouthoc@gmail.com
